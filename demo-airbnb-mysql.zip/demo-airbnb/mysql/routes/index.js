const userController = require('../controllers/user');
const addressController = require('../controllers/address');

module.exports = (app) => {

   app.get('/api', (req, res) => res.status(200).send ({
        message: 'Example project did not give you access to the api web services',
   }));

   app.post('/api/auth/register', userController.create);

   app.post('/api/auth/login', userController.signIn);

   app.get('/api/user/list', userController.list);

   app.get('/api/usuario/find/email/:email', userController.find);

   app.post('/api/user/:id/address/save', addressController.create);

   app.get('/api/address/all', addressController.list);

   app.get('/api/address/:id', addressController.get);

   app.delete('/api/address/delete/:id', addressController.delete);

   app.put('/api/address/update/:id', addressController.update);


   app.get('/api/pokemon/list', addressController.listPokemon);

   app.post('/api/pokemon', createPokemon.create);


};