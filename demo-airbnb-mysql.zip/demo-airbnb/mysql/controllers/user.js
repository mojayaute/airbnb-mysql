const { user } = require('../models'); 
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
module.exports = {

async create(req, res) {
    try {
        const { full_name, email, birthay, password } = req.body;
    
        const hashedPassword = await bcrypt.hash(password, 10);
    
        const newUser = await user.create({
        full_name,
        email,
        birthay,
        password: hashedPassword
        });
    
        return res.status(200).send(newUser);
    } catch (error) {
        return res.status(400).send(error.message);
    }
},

async signIn(req, res) {
    try {
        const foundUser = await user.findOne({
            where: {
              email: req.body.email,
            },
          });

        if (!foundUser || !bcrypt.compareSync(req.body.password, foundUser.password)) {
            return res.json({ status: false, message: 'Authentication failed. Invalid user or password.' });
        }
        return res.json({
            status: true,
            data: foundUser,
            message: 'Logged correctly',
            token: jwt.sign({ email: foundUser.email, full_name: foundUser.full_name, _id: foundUser._id }, 'RESTFULAPIs')
        });
    } catch (error) {
        console.log(error);
        return res.json({ status: false, data: error });
    }
},

  async list(_, res) {
    try {
      const users = await user.findAll();
      return res.status(200).send(users);
    } catch (error) {
      return res.status(400).send(error.message);
    }
  },

  async find(req, res) {
    try {
      const foundUser = await user.findAll({
        where: {
          email: req.params.email,
        },
      });
      return res.status(200).send(foundUser);
    } catch (error) {
      return res.status(400).send(error.message);
    }
  },
};