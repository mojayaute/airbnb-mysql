const { address } = require('../models'); 
const { pokemon } = require('../models'); 
module.exports = {

async create(req, res) {
    try {

        const { 
            country,
            state,
            city,
            street,
            zip } = req.body;
    
        const newAddress = await address.create({
            country,
            state,
            city,
            street,
            zip
        });
    
        return res.status(200).send(newAddress);
    } catch (error) {
        return res.status(400).send(error.message);
    }
},

  async list(_, res) {
    try {
      const addresses = await address.findAll();
      return res.status(200).send(addresses);
    } catch (error) {
      return res.status(400).send(error.message);
    }
  },

  async get(req, res) {
    try {
      const addressId = req.params.id;
      const addressFound = await address.findOne({
        where: {
          id: addressId
        }
      });
      if (!addressFound) {
        return res.status(404).send(`No se encontró ninguna dirección con ID ${addressId}.`);
      }
      return res.status(200).send(addressFound);
    } catch (error) {
      return res.status(400).send(error.message);
    }
  },

  async update(req, res) {
    try {
      const addressId = req.params.id;
      const updatedValues = req.body;

      const existingAddress = await address.findOne({
        where: {
          id: addressId
        }
      });

      if (!existingAddress) {
        return res.status(404).send(`No se encontró ninguna dirección con ID ${addressId}.`);
      }

       await address.update(updatedValues, {
        where: {
          id: addressId
        }
      });
      
        return res.status(200).send(existingAddress);
      
    } catch (error) {
      return res.status(400).send(error.message);
    }
  },

  async delete(req, res) {
    try {
      const addressId = req.params.id;
      const deletedAddress = await address.destroy({
        where: {
          id: addressId
        }
      });

      if (deletedAddress) {
        return res.status(200).send(`Address con ID ${addressId} eliminado correctamente.`);
      } else {
        return res.status(404).send(`No se encontró ningún address con ID ${addressId}.`);
      }

    } catch (error) {
      return res.status(400).send(error.message);
    }
  },

  async listPokemon(_, res) {
    try {
      const pokemons = await pokemon.findAll();
      return res.status(200).send(pokemons);
    } catch (error) {
      return res.status(400).send(error.message);
    }
  },

  async createPokemon(req, res) {
    try {

        const { id } = req.body;
    
        const newPokemon = await pokemon.create({id});
           
    
        return res.status(200).send(newPokemon);
    } catch (error) {
        return res.status(400).send(error.message);
    }
},

};