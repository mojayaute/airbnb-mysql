import Header from "../components/Header";
import DataTable from 'react-data-table-component';
import React, { useState, useEffect } from "react";
import AddressService from "../services/AddressService";
import { Link } from "react-router-dom";
import Swal from 'sweetalert2';



function Address() {
    const [addresses, setAddresses] = useState([]);
    const [search, setSearch] = useState("");

    useEffect(() => {
        getAddresses();
    }, []);

    const getAddresses = () => {
        AddressService.getAllPokemon().then(response => {
            setAddresses(response.data);
           
        }).catch(e => {
            console.error(e);
        });
    }

    const deleteAddress = (event) => {
        AddressService.remove(event.target.dataset.id).then(response => {
            const res = response.data;
            console.log(res);
            if (response.status) {
                Swal.fire({
                    title: 'Done',
                    text: 'Direccion eliminada correctamente',
                    icon: 'success',
                }).then((result) => {
                    getAddresses();
                });
            } else {
                Swal.fire({
                    title: 'Error',
                    text: 'Ha ocurrido un error intenta más tarde',
                    icon: 'error',
                }).then((result) => {
                    getAddresses();
                });
            }
        }).catch(e => {
            console.error(e);
        });
    }

    const columns = [
        {
            name: 'Country',
            selector: row => row.country
        },
        {
            name: 'State',
            selector: row => row.state
        },
        {
            name: 'City',
            selector: row => row.city
        },
        {
            name: 'Street',
            selector: row => row.street
        },
        {
            name: 'Zip',
            selector: row => row.zip
        },
        {
            name: 'Opciones',
            cell: row => <button className='btn btn-sm btn-danger' data-id={row.id}  onClick={deleteAddress}>Eliminar</button>,
        },
        {
            name: 'Opciones',
            cell: row => <button className="btn btn-sm btn-warning"> <Link to={`/address/edit/${row.id}`} style={{ color: "inherit", textDecoration: "none" }}>Actualizar</Link></button>
        }
    ];

    const handleFilter = event => {
        if (event.target.value) {
            const filtered = addresses.filter(row => {
                return row.country.toLowerCase().includes(event.target.value.toLowerCase()) ||
                    row.state.toLowerCase().includes(event.target.value.toLowerCase()) ||
                    row.city.toLowerCase().includes(event.target.value.toLowerCase()) ||
                    row.street.toLowerCase().includes(event.target.value.toLowerCase()) ||
                    row.zip.toLowerCase().includes(event.target.value.toLowerCase())
            })
            setAddresses(filtered)
        } else {
            getAddresses();
        }
    };

    return (
        <>
            <Header />
            <div className='container pt-5'>
                <div className="row mb-3">
                    <div className="col-md-6">
                        <h3>All Addresses</h3>
                    </div>
                    <div className="col-md-6 text-end">
                        <Link to={"/address/add"} className="btn btn-success">Add new</Link>
                    </div>
                </div>
                <div className="row justify-content-center">
                    <div className="col-md-12">
                        <div className='card p-4'>
                            <div className="row mb-4 justify-content-end">
                                <div className="col-md-3">
                                    <input type="text" onChange={handleFilter} name="search" placeholder="Search" className="form-control" />
                                </div>
                            </div>
                            <DataTable columns={columns} data={addresses} pagination />
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Address
