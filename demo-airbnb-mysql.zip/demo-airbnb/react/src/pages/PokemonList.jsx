import React, { useState, useEffect } from "react";
import Header from "../components/Header";
import { Link } from "react-router-dom";
import AddressService from "../services/AddressService";


function PokemonList() {
  const [pokemonList, setPokemonList] = useState([]);
  const [offset, setOffset] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);

  const [selectedPokemon, setSelectedPokemon] = useState(null);
  const itemsPerPage = 20;


  useEffect(() => {
    const fetchPokemon = async () => {
      const response = await fetch(`https://pokeapi.co/api/v2/pokemon/?limit=151`);
      const data = await response.json();
      setPokemonList(data.results);
    };

    fetchPokemon();
  }, []);


  const fetchPokemonDetail = async (url) => {
    try {
      const response = await fetch(url);
      const data = await response.json();
      console.log(data);
      setSelectedPokemon(data);
    } catch (error) {
      console.error("Error fetching Pokemon detail:", error);
    }
  };

  const handlePokemonClick = (url) => {
    const idPokemon = getIdUrl(url);
    AddressService.savePokemon(idPokemon).then(response => {
            const res = response.data;
            if (response.status) {
                Swal.fire({
                    title: 'Done',
                    text: 'Direccion eliminada correctamente',
                    icon: 'success',
                }).then((result) => {
                });
            } else {
                Swal.fire({
                    title: 'Error',
                    text: 'Ha ocurrido un error intenta más tarde',
                    icon: 'error',
                }).then((result) => {
                });
            }
        }).catch(e => {
            console.error(e);
        });
  };


  const getTotalPages = () => Math.ceil(pokemonList.length / itemsPerPage);
  const visiblePokemon = pokemonList.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const handleNextPage = () => {
    if (currentPage < getTotalPages()) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const getIdUrl = (url) => {
    const parts = url.split('/');
    const id = parts[parts.length - 2];
    return id;
  }

  return (

    <>
      <Header />
     
      <div>
      <div className='container pt-5'>
      <div className="row justify-content-center">
      <h2>Pokemon List</h2>

        {visiblePokemon.map((pokemon) => (
          <div className="col-md-6 bg-light p-2" >
            <Link to={`/pokemon/detail/${getIdUrl(pokemon.url)}`} >{pokemon.name} </Link>
            <button onClick={handlePokemonClick(pokemon.url)} className="btn" >Agregar</button>
            </div>
        ))}

     

        </div>
        <button onClick={handlePrevPage} className="btn" disabled={currentPage === 1}>Previous</button>
      <button onClick={handleNextPage} className="btn"  disabled={currentPage === getTotalPages()}>Next</button>
        </div>

      </div>
     
    </>
  );
}

export default PokemonList;