import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from "react-router-dom";
import Header from "../components/Header";


const PokemonDetail = ({ pokemonId }) => {
  const [pokemon, setPokemon] = useState(null);
  const { id } = useParams(); 

  useEffect(() => {
    const fetchPokemon = async () => {
      try {
        const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${id}/`);
        const data = await response.json();
        setPokemon(data);
      } catch (error) {
        console.error('Error fetching Pokemon:', error);
      }
    };

    fetchPokemon();
  }, [id]);

  if (!pokemon) {
    return <div>Loading...</div>;
  }

  return (
    <div>
    <Header />
     
    <div>
    <div className='container pt-5'>
    <div className="row justify-content-center">

    <div className="col-md-6 bg-light p-2" >

      
      <img src={pokemon.sprites.front_default} height="400" alt={pokemon.name} />
      </div>
      
      <div className="col-md-6 bg-light p-2" >

      <h2>{pokemon.name}</h2>
        <div>
          {pokemon.abilities.map((ability, index) => (
            <p key={index}>{ability.ability.name}</p>
          ))}
        </div>

        <div>
          Experience:
            <p>{pokemon.base_experience}</p>
            </div>
        
        </div>
    </div>
      

    </div>
    </div>
    </div>
  );
};

export default PokemonDetail;