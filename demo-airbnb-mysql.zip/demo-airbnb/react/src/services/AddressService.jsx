import http from "../http_common";

const save = (data, id) => {
    return http.post(`user/${id}/address/save`, data);
};

const getAll = () => {
    return http.get('/address/all');
};

const getById = id => {
    return http.get(`/address/${id}`);
};

const update = (id, data) => {
    return http.put(`/address/update/${id}`, data);
};

const remove = id => {
    return http.delete(`/address/delete/${id}`);
};


const getAllPokemon = () => {
    return http.get('/pokemon/list');
};

const savePokemon = (data) => {
    return http.post(`/pokemon/`, data);
};

export default {
    save,
    update,
    remove,
    getAll,
    savePokemon,
    getAllPokemon,
    getById
};
