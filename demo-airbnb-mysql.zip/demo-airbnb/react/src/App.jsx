import Login from './pages/Login'
import { Routes, Route } from "react-router-dom";
import Register from './pages/Register';
import ForgotPassword from './pages/ForgotPassword';
import Profile from './pages/Profile';
import FormAddress from './pages/FormAddress';
import Addresses from './pages/Addresses';
import PokemonList from './pages/PokemonList';
import PokemonDetail from './pages/PokemonDetail';

import Auth from './Auth';


function App() {
  return (
    <>
      <Routes>
        <Route exact path="/" element={<Login />} />
        <Route exact path="/register" element={<Register />} />
        <Route exact path="/forgot-password" element={<ForgotPassword />} />
        <Route exact path="/pokemon" element={<Auth><PokemonList /></Auth>} />
        <Route exact path="/profile" element={<Auth><Profile /></Auth>} />
        <Route exact path="/address/add" element={<Auth><FormAddress /></Auth>} />
        <Route exact path="/pokemon/detail/:id" element={<Auth><PokemonDetail /></Auth>} />
        <Route exact path="/address/edit/:id" element={<Auth><FormAddress /></Auth>} />
        <Route exact path="/address/all" element={<Auth><Addresses /></Auth>} />
      </Routes>
    </>
  )
}

export default App
